package Model;

public class Users {

    String Uname;

    public Users(String uname){
        Uname = uname;
    }

    public String getUname(){
        return Uname;
    }

    public void setUname(String uname){
        Uname = uname;
    }
}
