package com.example.student.mywallet;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Botton_bottum extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_botton_bottum);
    }
}
